<?php
//  في داخل المصفوفة الكلمات الثابتة في  الموقع
return [

    'dashboard'=>'لوحة التحكم',
    'Categories'=>'الأقسام',
    'Create New Category'=>'انشاء قسم جديد',
    'All Categories'=>' جميع الأقسام',
    'Add New Category'=>'اضافة قسم جديد',
    'Edit Category'=>'تعديل قسم',
    'Products'=>'المنتجات',
    'Create New Product'=>'انشاء منتج جديد',
    'All Products'=>' جميع المنتجات',
    'Add New Product'=>' اضافة منتج جديد',
    'Edit Product'=>'تعديل منتج ',
    'orders'=>'الطلبات',
    'payments'=>'المبيعات',
    'users'=>'المشتركين',
    'All Users'=>' جميع المشتركين',
    'Roles'=>'الصلاحيات',
    'All Roles'=>'جميع الصلاحيات',
    'Add New Role'=>'اضافة صلاحية جديد',
    'Earnings (Monthly)'=>'أرباح(شهرية)',
    'Earnings (Annual)'=>'أرباح(سنوية)',
    'Trash'=>'سلة المهملات',


];
