<?php
//  في داخل المصفوفة الكلمات الثابتة في  الموقع
return [
    'dashboard'=>'Tableau de bord',
    'categories'=>'Catégories',
    'products'=>'Des produits',
    'orders'=>'Ordres',
    'payments'=>'Paiements',
    'users'=>'utilisatrices',
];
