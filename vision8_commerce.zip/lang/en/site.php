<?php
//  في داخل المصفوفة الكلمات الثابتة في  الموقع
return [
    'dashboard'=>'Dashboard',
    'Categories'=>'Categories',
    'All Categories'=>'All Categories',
    'Add New Category'=>'Add New Category',
    'Create New Category'=>' Create New Category',
    'Edit Category'=>'Edit Category',
    'Products'=>'Products',
    'Create New Product'=>'Create New Product',
    'All Products'=>'All Products',
    'Add New Product'=>'Add New Product',
    'Edit Product'=>'Edit Product',
    'orders'=>'Orders',
    'payments'=>'Payments',
    'users'=>'Users',
    'All Users'=>'All Users',
    'Roles'=>'Roles',
    'All Roles'=>'All Roles',
    'Add New Role'=>'Add New Role',
    'Earnings (Monthly)'=>'Earnings (Monthly)',
    'Earnings (Annual)'=>'Earnings (Annual)',
    'Trash'=>'Trash',


];
